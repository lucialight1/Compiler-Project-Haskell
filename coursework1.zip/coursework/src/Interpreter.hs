{-# OPTIONS_GHC -Wno-incomplete-patterns #-}
module Interpreter
(
    AExp(..),
    BExp(..),
    Com (..),
    aval,
    bval,
    eval
) where

import Data.Map
import Machine


--TODO Task 2.1
data AExp =
    N Int | V Vname | Plus AExp AExp
    deriving (Eq, Read, Show)

--TODO Task 2.2
aval :: AExp -> State -> Val
aval (N val) state = val
aval (V variable) state = state ! variable
aval (Plus a b) state = aval a state + aval b state

--TODO Task 2.1
data BExp =
    Bc Bool | Not BExp | And BExp BExp | Less AExp AExp
    deriving (Eq, Read, Show)

--TODO Task 2.3
bval :: BExp -> State -> Bool
bval (Bc bool) state = bool
bval (Not bool) state = not (bval bool state)
bval (And a b) state = bval a state && bval b state
bval (Less a b) state = aval a state < aval b state

--TODO Task 2.1
data Com =
    Assign Vname AExp | Seq Com Com | If BExp Com Com | While BExp Com | SKIP
    deriving (Eq, Read, Show)

--TODO Task 2.4
eval :: Com -> State -> State
eval (Assign variable a) state = insert variable (aval a state) state
eval (Seq a b) state = eval b(eval a state)
eval (If bool c1 c2) state =  if bval bool state then eval c1 state else eval c2 state
eval (While bool c) state = if bval bool state then eval (While bool c) (eval c state) else state
eval SKIP state = state 
                           
                                            

