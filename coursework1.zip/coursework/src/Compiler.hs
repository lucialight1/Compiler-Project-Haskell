module Compiler
(
    acomp,
    bcomp,
    ccomp
) where

import Machine
import Interpreter

--TODO Task 3.1
acomp :: AExp -> [Instr]
acomp (N a) = [LOADI a]
acomp (V variable) = [LOAD variable]
acomp (Plus a b) = acomp a ++ acomp b ++ [ADD]

--TODO Task 3.2
bcomp :: BExp -> Bool -> Int -> [Instr]
bcomp (Bc b) bool n = [JMP n | b==bool]
bcomp (Not b) bool n = bcomp b (not bool) n
bcomp (And b1 b2) bool number =
    let compiledb2 = bcomp b2 bool number
        newjump = if bool then length compiledb2 else length compiledb2 + number
        compiledb1 = bcomp b1 False newjump
    in compiledb1 ++ compiledb2
bcomp (Less a b) bool n = acomp a ++ acomp b ++ (if bool then [JMPLESS n] else [JMPGE n])


--TODO Task 3.3
ccomp :: Com -> [Instr]
ccomp SKIP = []
ccomp (Assign b a) = acomp a ++ [STORE b]
ccomp (Seq c1 c2) = ccomp c1 ++ ccomp c2
ccomp (If b c1 c2) = if bcomp b False (length (ccomp c1) +1) /= [] then bcomp b False (length (ccomp c1) +1) ++ ccomp c1 ++ [JMP(length (ccomp c2))] ++ ccomp c2 else bcomp b False (length (ccomp c1) +1) ++ ccomp c1 ++ ccomp c2
ccomp (While b c1) = bcomp b False (length (ccomp c1) +1) ++ ccomp c1 ++ [JMP(-(length (bcomp b False (length (ccomp c1) + 1)) + length (ccomp c1) + 1))]

