{-# OPTIONS_GHC -Wno-incomplete-patterns #-}
module Machine
(      
        Vname,
        Val,
        State,
        Instr (..),
        Stack,
        Config,
        iexec,
        exec
) where

import Data.Map

--TODO Task 1.1
type Vname = String
--TODO Task 1.2
type Val = Int
--TODO Task 1.3
type State = Map Vname Val

--TODO Task 1.4
data Instr=
        LOADI Val | LOAD Vname | ADD | STORE Vname | JMP Int | JMPLESS Int | JMPGE Int
        deriving (Eq, Read, Show)

--TODO Task 1.5
type Stack = [Val]

--TODO Task 1.6
type Config = (Int, State, Stack)

--TODO Task 1.7
iexec :: Instr -> Config -> Config

iexec (LOADI n) (i, state, stack) = (i+1, state, n:stack)

iexec (LOAD variable) (i, state, stack) = (i+1, state, state ! variable:stack)

iexec ADD (i, state, first:second:stack) = (i+1, state, (first+second):stack)

iexec (STORE variable) (i, state, first:stack) = (i+1, insert variable first state, stack)

iexec (JMP int) (i, state, stack) = (i+int+1, state, stack)

iexec (JMPLESS int) (i, state, first:second:stack) | second < first = (i+int+1, state, stack)
                                                   | otherwise = (i+1, state, stack)
iexec (JMPGE int) (i, state, first:second:stack) | first <= second = (i+int+1, state, stack) 
                                                 | otherwise = (i+1, state, stack)                                            


--TODO Task 1.8
exec :: [Instr] -> Config -> Config
exec [] config = config
exec (x:instructions) state = exec instructions (iexec x state)
